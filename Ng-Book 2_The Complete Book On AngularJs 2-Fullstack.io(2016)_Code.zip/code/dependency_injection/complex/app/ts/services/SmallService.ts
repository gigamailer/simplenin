export class SmallService {
  run(): void {
    console.log('Small service...');
  }
}
