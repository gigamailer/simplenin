export class LargeService {
  run(): void {
    console.log('Large service...');
  }
}
