# ng-book 2: Basic Routing

## Quick start

```bash
# install 
npm install

# run
npm run go
```

Then visit [http://localhost:8080](http://localhost:8080) in your browser. 

