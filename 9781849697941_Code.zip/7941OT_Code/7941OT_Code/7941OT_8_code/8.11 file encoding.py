﻿# -*- coding: utf-8 -*- 
"""
Code illustration: 8.11
File Unicode Encoding
Tkinter GUI Application Development Hotshot
""" 
from Tkinter import *
root = Tk()
Label(root, text ='भारत में आपका स्वागत है' ).pack()
root.mainloop()

