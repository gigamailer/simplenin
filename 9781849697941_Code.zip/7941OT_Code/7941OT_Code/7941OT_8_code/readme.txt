====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 8: Miscellaneous Tips
====================================================================
Code Description:
Code 8.01: 			trace variable.py
Code 8.02: 			widget traversal.py
Code 8.03: 			validation mode demo.py
Code 8.04: 			percent substitutions demo.py
Code 8.05: 			key validation.py
Code 8.06: 			focus out validation.py
Code 8.07: 			formatting entry widget to display date.py
Code 8.08: 			tkfont demo.py
Code 8.09: 			font selector.py
Code 8.10: 			line encoding.py
Code 8.11: 			file encoding.py
Code 8.12: 			tkinter class hierarchy.py
Code 8.13: 			creating custom mixins.py	

