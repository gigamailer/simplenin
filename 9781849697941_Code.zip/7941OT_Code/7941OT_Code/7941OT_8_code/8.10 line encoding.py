﻿"""
Code illustration: 8.10
Line Unicode Encoding
Tkinter GUI Application Development Hotshot
""" 
from Tkinter import *
t = Tk()
Label(text =u'भारत में आपका स्वागत है' ).pack()
t.mainloop()

