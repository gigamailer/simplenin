====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 6: Drawing Program
====================================================================
Code Description:
Code framework.py:  Creating a basic structure for our GUI framework
Code 6.01: 			Creating the Overall Structure for our Drawing Program
Code 6.02: 			Handling Mouse Events
Code 6.03: 			Drawing Basic Shapes on the Canvas
Code 6.04: 			Adding TopBar to Display options for each of the selected buttons
Code 6.05: 			Adding Features of 'deleteObj', 'fillObj', 'moveToTop', 'dragItem'


Directory 'icons' contains all images used in the program
