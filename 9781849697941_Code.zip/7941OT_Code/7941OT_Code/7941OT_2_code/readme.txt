====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 2: Make a Text-Editor cum Notepad
====================================================================
List of code samples:

2.01:   Add top-level window/ Add menubuttons
2.02:   Add menu-items within each menu button/ Add labels to hold shortcut toolbar and line number
2.03:   Leveraging power of text widget built-in options
2.04:   Indexing and tagging - implementation of 'select all' and 'find all'
2.05:   A demonstration of different types of top-level window
2.06:   A demonstration of tkFileDialog
2.07:   Adding File>New,File>Open,File>Save and File>Save As functionality
2.08:   A demonstration of tkMessageBox
2.09:   Add About, Help & Quit Functionality
2.10:   Add shortcut icon toolbar/ display line numbers/ highlight current line
2.11:   Add infobar
2.12:   Add event handling/ contextual menu and titlebar icon



