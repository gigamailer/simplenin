====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 9: Appendices
====================================================================
Code Description:
Code 9.01: 			Demo of Available Cursors.py

