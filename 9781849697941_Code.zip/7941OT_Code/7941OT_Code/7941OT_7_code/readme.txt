====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 7: Fun Project Ideas
====================================================================
Code Description:
Code 7.01: 			Screensaver
Code 7.02: 			Threading with Queue Simple Demo
Code 7.03: 			Snake Game
Code 7.04: 			Demo of Network Programming With Socket Module
Code 7.05: 			Fetching web content with urllib -  demo
Code 7.06: 			Weather Reporter
Code 7.07: 			Phonebook Application
Code 7.08: 			Piechart
Code 7.09: 			Scatter Plot
Code 7.10: 			Bar Graph	
Code 7.11: 			Embedding Matplotlib graph on tkinter

Directory 'icons' contains all images used in the program
Directory 'weatherimages' contains all images used by Weather Reporter program
