"""
Code illustration: 1.01
Your first GUI application - the top level window
Tkinter GUI Application Development Hotshot
""" 

from Tkinter import * #(1)
root = Tk()           #(2) 
root.mainloop()       #(3) 

