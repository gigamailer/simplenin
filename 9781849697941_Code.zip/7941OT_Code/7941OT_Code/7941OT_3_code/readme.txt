====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 3: Drum Machine
====================================================================
List of code samples:

3.01:   Creating OOP Based GUI structure
3.02:   Setting up Widgets
3.03:   Creating the Right Drum Pad or the Pattern Editor
3.04:   Loading Drum Samples
3.05:   Playing Sound Files with pymedia module
3.06:   Demo of widget.config()
3.07:   Tkinter and Threading
3.08:   Adding support for multiple beat patterns
3.09:   Object Persistence: pickling and unpickling
3.10:   tkinter versus ttk Themed Widgets / new widgets introduced in ttk
3.11:   tttk widgets styling and theming explained
3.12:   Finalizing our Drum Machine



