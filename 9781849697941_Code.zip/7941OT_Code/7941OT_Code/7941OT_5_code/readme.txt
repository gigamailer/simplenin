====================================================================
Code Readme
Tkinter GUI Application Development Hotshot
Chapter 5: Audio Player
====================================================================
Code Description:

Code 5.01: Getting the Audio to Play
Code 5.02: Adding a Playlist
Code 5.03: Adding More Controls to The Player
Code 5.04: Adding the Top Display Console
Code 5.05: Looping Over Tracks
Code 5.06: Adding Contextual Menu
Code 5.07: Adding ToolTip & Finalizing our Player


Directory 'icons' contains all images used in the program

@author Bhaskar Chaudhary